from . import hr_payslip
from . import hr_employee
from . import hr_projection
from . import res_config_settings
