================================
Cuba - Nóminas
================================

Configuración
=============

Uso
=====

Bug Tracker
===========


Dependencias de terceros
=============
Odoo Mates: https://github.com/odoomates/odooapps


Authors
=============

* Comunidad Cubana de Odoo

Contributors
=============

* Segu
