# localizacion_cubana
localizacion cubana para odoo 14
