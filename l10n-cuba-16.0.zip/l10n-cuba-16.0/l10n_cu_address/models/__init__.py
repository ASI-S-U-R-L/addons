# -*- coding: utf-8 -*-

from . import res_municipality
from . import res_state
from . import res_partner